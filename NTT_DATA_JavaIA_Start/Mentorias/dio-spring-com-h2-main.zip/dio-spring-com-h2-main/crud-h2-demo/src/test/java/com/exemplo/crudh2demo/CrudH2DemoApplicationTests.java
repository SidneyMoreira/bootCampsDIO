package com.exemplo.crudh2demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudH2DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
