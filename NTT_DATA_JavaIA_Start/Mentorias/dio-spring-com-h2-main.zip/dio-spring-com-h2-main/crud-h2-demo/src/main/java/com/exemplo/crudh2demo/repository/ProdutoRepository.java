package com.exemplo.crudh2demo.repository;

import com.exemplo.crudh2demo.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    // Métodos de consulta personalizados
    List<Produto> findByNomeContaining(String nome);
    List<Produto> findByPrecoLessThanEqual(Double precoMaximo);
}
