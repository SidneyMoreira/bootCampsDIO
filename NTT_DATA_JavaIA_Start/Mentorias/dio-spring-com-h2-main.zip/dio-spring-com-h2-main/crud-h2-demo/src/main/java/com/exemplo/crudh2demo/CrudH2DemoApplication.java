package com.exemplo.crudh2demo;

import com.exemplo.crudh2demo.model.Produto;
import com.exemplo.crudh2demo.service.ProdutoService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudH2DemoApplication implements CommandLineRunner {

	private final ProdutoService produtoService;

	public CrudH2DemoApplication(ProdutoService produtoService) {
		this.produtoService = produtoService;
	}

	public static void main(String[] args) {
		SpringApplication.run(CrudH2DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("\n=== INICIANDO DEMONSTRAÇÃO CRUD ===\n");

		// CREATE - Criando produtos
		System.out.println("Criando produtos...");
		Produto p1 = new Produto("Notebook", "Notebook i7 16GB", 4500.0);
		Produto p2 = new Produto("Smartphone", "Smartphone 128GB", 2500.0);
		Produto p3 = new Produto("Tablet", "Tablet 10 polegadas", 1500.0);

		produtoService.salvar(p1);
		produtoService.salvar(p2);
		produtoService.salvar(p3);

		System.out.println("Produtos criados com sucesso!");

		// READ - Listando todos os produtos
		System.out.println("\n=== TODOS OS PRODUTOS ===");
		produtoService.listarTodos().forEach(p ->
				System.out.println(p.getId() + ": " + p.getNome() + " - R$" + p.getPreco())
		);

		// READ - Buscando por nome
		System.out.println("\n=== PRODUTOS COM 'PHONE' NO NOME ===");
		produtoService.buscarPorNome("phone").forEach(p ->
				System.out.println(p.getId() + ": " + p.getNome())
		);

		// UPDATE - Atualizando um produto
		System.out.println("\n=== ATUALIZANDO PRODUTO ===");
		Produto produtoParaAtualizar = produtoService.buscarPorId(1L);
		System.out.println("Antes: " + produtoParaAtualizar);

		produtoParaAtualizar.setPreco(4299.99);
		produtoParaAtualizar.setDescricao("Notebook i7 16GB SSD 512GB");
		Produto atualizado = produtoService.salvar(produtoParaAtualizar);

		System.out.println("Depois: " + atualizado);

		// DELETE - Removendo um produto
		System.out.println("\n=== REMOVENDO PRODUTO ===");
		System.out.println("Removendo produto com ID 3...");
		produtoService.remover(3L);

		System.out.println("\n=== LISTA APÓS REMOÇÃO ===");
		produtoService.listarTodos().forEach(p ->
				System.out.println(p.getId() + ": " + p.getNome())
		);

		// Busca por preço
		System.out.println("\n=== PRODUTOS COM PREÇO ATÉ R$3000 ===");
		produtoService.buscarPorPrecoMaximo(3000.0).forEach(p ->
				System.out.println(p.getId() + ": " + p.getNome() + " - R$" + p.getPreco())
		);

		System.out.println("\n=== FIM DA DEMONSTRAÇÃO ===");
		System.out.println("\nAcesse o console H2: http://localhost:8080/h2-console");
	}
}
