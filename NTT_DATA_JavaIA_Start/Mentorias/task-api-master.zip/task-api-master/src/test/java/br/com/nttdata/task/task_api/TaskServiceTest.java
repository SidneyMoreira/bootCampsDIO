package br.com.nttdata.task.task_api;

import br.com.nttdata.task.task_api.model.Task;
import br.com.nttdata.task.task_api.service.TaskService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;

import static org.hibernate.validator.internal.util.Contracts.assertTrue;
import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;

public class TaskServiceTest {

    private TaskService taskService;

    @Test
    public void shouldReturnOnlyFinishedTasks() {
        // Given
        // Aqui você pode criar uma lista de tarefas com diferentes status, incluindo "FINALIZADA"
        // Por exemplo, você pode usar Mockito para simular o comportamento do TaskRepository
        taskService = Mockito.mock(TaskService.class);
        // When
        List<Task> allCompletedTasks = taskService.getAllCompletedTasks();

        // Then
        // Aqui você pode verificar se a lista retornada contém apenas as tarefas com status "FINALIZADA"
        // Por exemplo, você pode usar Mockito.verify para garantir que o método foi chamado corretamente
        Mockito.verify(taskService).getAllCompletedTasks();
        // E você pode usar assertEquals ou assertTrue para verificar o conteúdo da lista retornada
        List<Task> actualTasks = taskService.getAllCompletedTasks();
        assertTrue(actualTasks.stream().allMatch(task -> "FINALIZADA".equals(task.getStatus())),
                "All tasks should have status 'FINALIZADA'");

    }
}
