package br.com.nttdata.task.task_api.controller;

import br.com.nttdata.task.task_api.model.Task;
import br.com.nttdata.task.task_api.service.TaskService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    // Aqui você pode adicionar métodos para manipular as tarefas, como criar, listar, atualizar e excluir tarefas
    // Por exemplo, um método para listar todas as tarefas:

    @GetMapping("/completed")
    public List<Task> getAllTasksWithFinishStatus() {
        return taskService.getAllCompletedTasks();
    }

    // cria metodo para buscar todas as tarefas
    @GetMapping
    public List<Task> getAllTasks() {
        return taskService.getAllTasks();
    }

     // Exemplo de método para buscar uma tarefa por ID:
     @GetMapping("/{id}")
     public ResponseEntity<Task> getTaskById(@PathVariable Long id) {
         Task task = taskService.getTaskById(id);
         if (task != null) {
             return ResponseEntity.ok(task);
         } else {
             return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
         }
     }

    // Exemplo de método para criar uma nova tarefa:
     @PostMapping
     public ResponseEntity<Task> createTask(@RequestBody Task task) {
         Task createdTask = taskService.createTask(task);
         return ResponseEntity.status(HttpStatus.CREATED).body(createdTask);
     }

    // Exemplo de método para atualizar uma tarefa existente:
    @PutMapping("/{id}")
    public ResponseEntity<Task> updateTask(@PathVariable Long id, @RequestBody Task task) {
        Task updatedTask = taskService.updateTask(id, task);
        return ResponseEntity.ok(updatedTask);
    }
}
