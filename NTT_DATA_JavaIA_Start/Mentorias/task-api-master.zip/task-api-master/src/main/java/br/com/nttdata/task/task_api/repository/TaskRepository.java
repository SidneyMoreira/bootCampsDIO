package br.com.nttdata.task.task_api.repository;

import br.com.nttdata.task.task_api.model.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {

    // Aqui você pode adicionar métodos personalizados de consulta, se necessário
    // Por exemplo, para buscar tarefas por status ou por usuário

    // Exemplo de método personalizado:
    List<Task> findByStatus(String status);
}
