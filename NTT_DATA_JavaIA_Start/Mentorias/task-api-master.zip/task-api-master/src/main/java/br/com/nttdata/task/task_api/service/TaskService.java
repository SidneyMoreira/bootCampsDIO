package br.com.nttdata.task.task_api.service;

import br.com.nttdata.task.task_api.model.Task;

import java.util.List;

public interface TaskService {
    // Cria um método que retorna todas as tarefas com status FINALIZADA
    List<Task> getAllCompletedTasks();

    // Cria um método que retorna todas as tarefas com qualquer status
    List<Task> getAllTasks();

    // cria metodo para registrar uma nova tarefa
    Task createTask(Task task);

    //cria metodo para atualizar uma tarefa existente
    Task updateTask(Long id, Task task);

    // cria metodo para excluir uma tarefa
    void deleteTask(Long id);

    Task getTaskById(Long id);
}
