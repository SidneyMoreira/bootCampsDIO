package br.com.nttdata.task.task_api.model;

public enum Status {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}
