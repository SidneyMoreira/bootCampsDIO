package br.com.nttdata.task.task_api.service;

import br.com.nttdata.task.task_api.model.Task;
import br.com.nttdata.task.task_api.repository.TaskRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;

    public TaskServiceImpl(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    // Cria um método que retorna todas as tarefas com status FINALIZADA
    @Override
    public List<Task> getAllCompletedTasks() {
        // Aqui você implementaria a lógica para buscar as tarefas finalizadas
        // Por enquanto, vamos retornar uma string de exemplo
        return taskRepository.findByStatus("FINALIZADA");
    }

    @Override
    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    // cria metodo para registrar uma nova tarefa
    @Override
    public Task createTask(Task task) {
        // Aqui você implementaria a lógica para salvar uma nova tarefa
        return taskRepository.save(task);
    }

    //cria metodo para atualizar uma tarefa existente
    @Override
    public Task updateTask(Long id, Task task) {
        // Aqui você implementaria a lógica para atualizar uma tarefa existente
        // Primeiro, você deve verificar se a tarefa existe
        return taskRepository.findById(id)
                .map(existingTask -> {
                    existingTask.setTitle(task.getTitle());
                    existingTask.setDescription(task.getDescription());
                    return taskRepository.save(existingTask);
                })
                .orElseThrow(() -> new RuntimeException("Task not found with id " + id));
    }

    // cria metodo para excluir uma tarefa
    @Override
    public void deleteTask(Long id) {
        // Aqui você implementaria a lógica para excluir uma tarefa
        taskRepository.deleteById(id);
    }

    @Override
    public Task getTaskById(Long id) {
        return taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found with id " + id));
    }
}
